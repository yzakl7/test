export class Objeto {
  $key: string;
  name: string;
  address: string;
  phone: string;
  email: string;
  role: string;
  origyn: string;
  plates: string;
  color: string;
  qty: number;
  price: number;
  position: string;
  companyName: string;
}
