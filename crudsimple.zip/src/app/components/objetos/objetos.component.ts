import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-objetos',
  templateUrl: './objetos.component.html',
  styleUrls: ['./objetos.component.scss']
})
export class ObjetosComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
